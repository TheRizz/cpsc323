# cpsc323
Syntactical Analyzer with lexer

To run:
1. run syntacticalanaysis.py
2. select the input file containing code
3. look at output file named outputSA.txt for results
4. symbol table included in the output results in outputSA

SAinput.txt is an example of an input
